To install BioFabric, unzip this archive as a folder on your desktop. Go into the folder. 
If you want to install BioFabric in the Windows "Program Files" folder, you will need to 
run the BioFabricInstaller as an Admin user. To do that, right-click on the BioFabricInstaller 
program and choose "Run as administrator". If you are not an Admin, you will need to install 
it somewhere within your home directory by changing the install location as part of the 
installation. Once the installation is complete, you can right-click on the BioFabric program
and select "Create shortcut", then e.g. drag it to your desktop.
